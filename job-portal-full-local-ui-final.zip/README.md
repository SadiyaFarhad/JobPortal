
Job Portal Full Local - FINAL
Run backend:
cd backend
cp .env.example .env
npm install
npm start

Run frontend:
cd frontend
npx serve .
Open http://localhost:5500
